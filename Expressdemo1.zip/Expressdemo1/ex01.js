//GET demo in Express
/*const express=require("express")
const app=express()
const root=__dirname
app.get("/",(req,res)=>res.send("Testing Express"))
app.get("/Home",(req,res)=>res.send("<h1>Home Page of the Application</h1>"))
app.get("/Newuser",(req,res)=>res.sendFile(root+"/UserRegistration.html"))//use this to send static web pages as response....
//Express makes things simple in nodejs...
app.get("/Register",(req,res)=>{
    const name=req.query.uname;//uname is the name of the text box placed in the html
    const address=req.query.uaddress;
    const phone=req.query.uphone;
    res.send(`<h1>${name} from ${address} has been registered with us!!!!</h1><hr/>The Contact phone no is ${phone}`)
})
app.listen(1234,()=>{
    console.log("server is running at 1234")
})*/


const express=require('express')
const parser=require("body-parser")
const app=express()
const root= __dirname;
app.use(parser.urlencoded({extended:false}))
app.get("/",(req,res)=>res.send("Testing Express"))
app.get("/Newuser",(req,res)=>res.sendFile(root+"/userRegistration.html"))
app.get("/Register",(req,res)=>{
    const name=req.query.uname
    const address=req.query.uaddress
    const phone=req.query.uphone
    res.send(`<h1>${name} from ${address} has been registered with ${phone} number</h1>`)
})
app.post("/Register",(req,res)=>{
    //console.log(req.body);
    if(req.body==null){
        res.send("<h1>There is no data posted to the browser</h1>")
    }
    else{
        const name=req.body.uname
        const address=req.body.uaddress
        const phone=req.body.uphone
        res.send(`<h1>${name} from ${address} has been registered with ${phone} number</h1>`)  
    }
})
app.listen(1234,()=>{
    console.log("Server is running at 1234")
})
/*
//Post demo using Express
const express=require("express")
const parser=require("body-parser")//This is required for processing the posted data obtained through http post
//if we have have multiple folders then we need path
const path=require("path")
const app=express()
//This will make the express use the parser.
app.use(parser.urlencoded({extended:false}))
const root=__dirname
//When we post the data then the posted data is sento the server as a body.
//we need a body-parser to parse the contents of the data.express expects to create a body parser and include it in the pipeline of processing data...
app.post("/Register",(req,res)=>{
    // console.log(req.body)  //to check what is the content of the body
     if(req.body==null)
     {
         //This code would execute if ur server does not 
         res.send("<h1>Thiere is no data posted to the browser</h1>")
     }
     else
     {
         const name=req.body.uname;//uname is the name of the text box placed in the html
     const address=req.body.uaddress;
     const phone=req.body.uphone;
     res.send(`<h1>${name} from ${address} has been registered with us!!!!</h1><hr/>The Contact phone no is ${phone}.This data is secured as it is posted to the server`)
 }
     
 })
app.get("/",(req,res)=>res.send("Testing Express"))
app.get("/Home",(req,res)=>res.send("<h1>Home Page of the Application</h1>"))
app.get("/Newuser",(req,res)=>res.sendFile(root+"/UserRegistration.html"))//use this to send static web pages as response....
//Express makes things simple in nodejs...
app.get("/Register",(req,res)=>{
    const name=req.query.uname;//uname is the name of the text box placed in the html
    const address=req.query.uaddress;
    const phone=req.query.uphone;
    res.send(`<h1>${name} from ${address} has been registered with us!!!!</h1><hr/>The Contact phone no is ${phone}`)
})

app.listen(1234,()=>{
    console.log("server is running at 1234")
})*/